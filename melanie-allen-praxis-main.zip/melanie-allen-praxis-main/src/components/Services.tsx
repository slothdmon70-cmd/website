import { Brain, Sparkles, HeartHandshake, Leaf } from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Brain,
      title: "Verhaltenstherapie",
      description:
        "Wissenschaftlich fundierte Methoden zur Bewältigung von Ängsten, Depressionen und anderen psychischen Belastungen.",
    },
    {
      icon: HeartHandshake,
      title: "Paartherapie",
      description:
        "Unterstützung für Paare bei Kommunikationsproblemen, Konflikten und der Stärkung Ihrer Beziehung.",
    },
    {
      icon: Sparkles,
      title: "Burnout-Prävention",
      description:
        "Strategien zur Stressbewältigung und Wiederherstellung Ihrer inneren Balance im beruflichen und privaten Leben.",
    },
    {
      icon: Leaf,
      title: "Achtsamkeitsbasierte Therapie",
      description:
        "Integration von Achtsamkeitstechniken zur Förderung von Selbstwahrnehmung und emotionaler Regulation.",
    },
  ];

  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-primary font-sans text-sm tracking-widest uppercase mb-3">
              Meine Leistungen
            </p>
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6">
              Therapeutische Angebote
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mb-8" />
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Ich biete verschiedene therapeutische Ansätze an, die individuell auf 
              Ihre Bedürfnisse und Ihre persönliche Situation abgestimmt werden.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="group p-8 rounded-2xl bg-card border border-border hover:border-primary/30 hover:shadow-xl transition-all duration-300"
              >
                <div className="w-14 h-14 bg-accent group-hover:bg-primary/10 rounded-xl flex items-center justify-center mb-6 transition-colors duration-300">
                  <service.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-serif text-xl text-foreground mb-3">
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-16 p-8 md:p-12 rounded-2xl bg-gradient-to-br from-accent/50 to-sage-light/30 text-center">
            <h3 className="font-serif text-2xl text-foreground mb-4">
              Erstgespräch
            </h3>
            <p className="text-muted-foreground max-w-xl mx-auto mb-6">
              In einem unverbindlichen Erstgespräch lernen wir uns kennen und besprechen 
              gemeinsam Ihr Anliegen. So können wir herausfinden, ob die Zusammenarbeit 
              für Sie passend ist.
            </p>
            <p className="text-primary font-sans text-lg">
              Dauer: ca. 50 Minuten
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
