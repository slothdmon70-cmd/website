import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const Contact = () => {
  const contactInfo = [
    {
      icon: MapPin,
      title: "Adresse",
      lines: ["Rehainer Straße 1", "06917 Jessen (Elster)"],
    },
    {
      icon: Phone,
      title: "Telefon",
      lines: ["+49 35372 049990"],
    },
    {
      icon: Mail,
      title: "E-Mail",
      lines: ["info@praxis-allen.de"],
    },
    {
      icon: Clock,
      title: "Sprechzeiten",
      lines: [
        "Mo, Di, Do: 08:00–12:30, 15:00–16:30",
        "Mi: 08:00–12:30",
        "Fr: 08:00–13:00",
      ],
    },
  ];

  return (
    <section id="contact" className="py-24 bg-card">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-primary font-sans text-sm tracking-widest uppercase mb-3">
              Kontakt
            </p>
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6">
              Kontakt aufnehmen
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mb-8" />
            <p className="text-muted-foreground max-w-xl mx-auto">
              Für Terminvereinbarungen oder Fragen erreichen Sie die Praxis 
              telefonisch oder per E-Mail.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-8">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex gap-4">
                  <div className="w-12 h-12 bg-accent rounded-xl flex items-center justify-center flex-shrink-0">
                    <info.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-sans font-medium text-foreground mb-1">
                      {info.title}
                    </h3>
                    {info.lines.map((line, lineIndex) => (
                      <p key={lineIndex} className="text-muted-foreground text-sm">
                        {line}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-background rounded-2xl p-8 border border-border">
              <h3 className="font-serif text-xl text-foreground mb-6">
                Nachricht senden
              </h3>
              <form className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-sans text-muted-foreground mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors"
                    placeholder="Ihr Name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-sans text-muted-foreground mb-2">
                    E-Mail
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors"
                    placeholder="Ihre E-Mail-Adresse"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-sans text-muted-foreground mb-2">
                    Nachricht
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors resize-none"
                    placeholder="Ihre Nachricht..."
                  />
                </div>
                <Button type="submit" className="w-full">
                  Nachricht senden
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
