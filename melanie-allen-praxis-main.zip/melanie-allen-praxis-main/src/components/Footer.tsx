const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-12 bg-foreground text-primary-foreground">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
              <p className="font-serif text-xl mb-1">Melanie Allen</p>
              <p className="text-primary-foreground/70 text-sm">
                Psychotherapeutische Praxis in Jessen
              </p>
            </div>

            <nav>
              <ul className="flex flex-wrap justify-center gap-6 text-sm">
                <li>
                  <a
                    href="#home"
                    className="text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                  >
                    Startseite
                  </a>
                </li>
                <li>
                  <a
                    href="#about"
                    className="text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                  >
                    Über mich
                  </a>
                </li>
                <li>
                  <a
                    href="#services"
                    className="text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                  >
                    Leistungen
                  </a>
                </li>
                <li>
                  <a
                    href="#contact"
                    className="text-primary-foreground/70 hover:text-primary-foreground transition-colors"
                  >
                    Kontakt
                  </a>
                </li>
              </ul>
            </nav>
          </div>

          <div className="mt-8 pt-8 border-t border-primary-foreground/20 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-primary-foreground/60">
            <p>© {currentYear} Melanie Allen. Alle Rechte vorbehalten.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-primary-foreground transition-colors">
                Impressum
              </a>
              <a href="#" className="hover:text-primary-foreground transition-colors">
                Datenschutz
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
