import { Heart, Shield, Users } from "lucide-react";

const About = () => {
  const values = [
    {
      icon: Heart,
      title: "Einfühlsamkeit",
      description: "Ich begegne Ihnen mit Wärme, Verständnis und echtem Interesse an Ihrer Geschichte.",
    },
    {
      icon: Shield,
      title: "Vertrauen",
      description: "Ein geschützter Raum, in dem Sie sich sicher fühlen und offen sprechen können.",
    },
    {
      icon: Users,
      title: "Zusammenarbeit",
      description: "Gemeinsam entwickeln wir Wege, die zu Ihrer individuellen Situation passen.",
    },
  ];

  return (
    <section id="about" className="py-24 bg-card">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-primary font-sans text-sm tracking-widest uppercase mb-3">
              Über mich
            </p>
            <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-6">
              Melanie Allen
            </h2>
            <div className="w-16 h-0.5 bg-primary mx-auto mb-8" />
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
            <div className="order-2 md:order-1">
              <p className="text-muted-foreground leading-relaxed mb-6">
                In der Praxis werden Patienten mit verschiedenen psychischen Belastungen 
                und Erkrankungen behandelt.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Die Therapie findet in einem geschützten Rahmen statt. 
                Ziel ist es, gemeinsam Lösungswege zu erarbeiten und 
                vorhandene Ressourcen zu stärken.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Die Behandlung erfolgt auf Grundlage wissenschaftlich anerkannter 
                Therapieverfahren.
              </p>
            </div>
            
            <div className="order-1 md:order-2">
              <div className="aspect-[4/5] bg-gradient-to-br from-sage-light to-accent rounded-2xl flex items-center justify-center">
                <div className="text-center p-8">
                  <div className="w-32 h-32 bg-primary/20 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="font-serif text-4xl text-primary">MA</span>
                  </div>
                  <p className="text-muted-foreground text-sm">Approbierte Psychotherapeutin</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="text-center p-6 rounded-xl bg-background hover:shadow-lg transition-shadow duration-300"
              >
                <div className="w-14 h-14 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <value.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-serif text-xl text-foreground mb-3">{value.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
