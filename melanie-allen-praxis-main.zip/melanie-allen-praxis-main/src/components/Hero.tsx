import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

const Hero = () => {
  return (
    <section
      id="home"
      className="min-h-screen flex items-center justify-center relative bg-gradient-to-b from-accent/30 to-background pt-20"
    >
      <div className="container mx-auto px-6 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-primary font-sans text-sm md:text-base tracking-widest uppercase mb-4 animate-fade-in opacity-0" style={{ animationDelay: "0.2s" }}>
            Psychotherapeutische Praxis in Jessen
          </p>
          
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground leading-tight mb-6 animate-fade-in opacity-0" style={{ animationDelay: "0.4s" }}>
            Psychotherapie
            <span className="block text-primary mt-2">in Jessen (Elster)</span>
          </h1>
          
          <p className="text-muted-foreground text-lg md:text-xl leading-relaxed mb-10 max-w-2xl mx-auto animate-fade-in opacity-0" style={{ animationDelay: "0.6s" }}>
            Psychotherapeutische Unterstützung bei seelischen Belastungen 
            und psychischen Erkrankungen.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in opacity-0" style={{ animationDelay: "0.8s" }}>
            <Button asChild size="lg" className="font-sans">
              <a href="#contact">Termin vereinbaren</a>
            </Button>
            <Button asChild variant="outline" size="lg" className="font-sans">
              <a href="#about">Mehr erfahren</a>
            </Button>
          </div>
        </div>
      </div>
      
      <a
        href="#about"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-primary transition-colors animate-bounce"
        aria-label="Nach unten scrollen"
      >
        <ChevronDown size={32} />
      </a>
    </section>
  );
};

export default Hero;
